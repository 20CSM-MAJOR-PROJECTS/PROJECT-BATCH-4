import React from "react";// Import your custom CSS file
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faThumbsUp } from "@fortawesome/free-solid-svg-icons";
const FAQ = () => {
  return (
    <div className="faq-page">
      <h1 className="faq-heading">Frequently Asked Questions</h1>
      <div className="faq-cards">
        <div className="faq-card faq-card1">
          <div className="card-inner">
            <div className="card-front">
              <div className="question-text">Is my identity safe?</div>
            </div>
            <div className="card-back">
              <div className="answer-text">Absolutely. We prioritize your safety and privacy above all else. When you submit a report through our platform, we use advanced technology to ensure your identity remains confidential. No one, including law enforcement, will have access to your personal information. Your safety is our utmost concern</div>
            </div>
          </div>
      </div>
      <div className="faq-card faq-card2">
          <div className="card-inner">
            <div className="card-front">
              <div className="question-text">What happens after I submit a report?</div>
            </div>
            <div className="card-back">
              <div className="answer-text">Once you submit a report, our dedicated team of law enforcement professionals promptly reviews the information you've provided. If your report contains vital details about a suspicious activity or crime, it will be investigated thoroughly. Rest assured that we take every report seriously and will take appropriate action to address the situation.</div>
            </div>
          </div>
      </div>
      <div className="faq-card faq-card3">
          <div className="card-inner">
            <div className="card-front">
              <div className="question-text">Can I trust the system to keep my information secure?</div>
            </div>
            <div className="card-back">
              <div className="answer-text">Yes, you can trust our system to keep your information secure. We implement stringent security measures, inclu data encryption and blockchain technology, to protect you anonymity and the confidentiality of your report. Our commitment to your privacy is unwavering, and we have designed our platform with the latest security protocols to ensure your information remains safe and inaccessible to unauthorized parties.</div>
            </div>
          </div>
      </div>
      </div>
      <div className="support-us">
        <div className="support-icon">
          <FontAwesomeIcon icon={faThumbsUp} className="thumbs-up" />
        </div>
        <div className="support-text">
          <h2>Support Us</h2>
        </div>
      </div>
    </div>
  );
};

export default FAQ;
