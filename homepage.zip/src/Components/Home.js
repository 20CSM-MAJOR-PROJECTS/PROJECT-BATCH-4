import React from "react";
import Navbar from "./Navbar";
import { FiArrowRight } from "react-icons/fi";
import { BsFillPlayCircleFill } from "react-icons/bs";

const Home = () => {
  return (
    <div className="home-container">
      <Navbar />
      <div className="home-banner-container">
            <div className="home-text-section">
                <h1 className="home-heading">
                    Anonymous Tip-Offs
                </h1>
                <p className="home-text">
                A One Stop Solution For Safely Reporting And Preventing Crime
                </p>
                <div className="about-buttons-container">
                <button className="secondary-button">
                    Our Goal <FiArrowRight />{" "}
                </button>
                <button className="watch-video-button">
            <BsFillPlayCircleFill /> Watch Video
          </button>
        </div>
            </div>
        </div>
    </div>
  );
};

export default Home;