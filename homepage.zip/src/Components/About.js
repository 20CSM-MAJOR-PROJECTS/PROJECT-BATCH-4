import React from "react";
import AboutBackground from "../Assets/about-background.png";
import AboutpageImage from "../Assets/about-page-image.png";
import Supporter2logo from "../Assets/supporter2-logo.png";
import Supporter1logo from "../Assets/supporter1-logo.png";
import { BsFillPlayCircleFill } from "react-icons/bs";

const About = () => {
  return (
    <div className="about-section-container">
      {/*<div className="about-background-image-container">
        <img src={AboutBackground} alt="" />
  </div>*/}
      <div className="about-section-image-container">
        <img src={AboutpageImage} alt="" />
      </div>
      <div className="about-section-text-container">
        <div className="safety-information-container">
        <div className="safety-information-container">
          <p class="primary-text">THINKING ABOUT YOUR SAFETY?</p>
          <p>
            We understand that you may have concerns about your safety or fear
            of retaliation when reporting suspicious activities. Reporting
            anonymously ensures:
          </p>
          <ul>
            <li>Your identity remains confidential.</li>
            <li>You can contribute to a safer community without fear.</li>
            <li>Authorities can take action while protecting your privacy.</li>
          </ul>
          <p className="primary-subheading">How it Works:</p>
          <ol>
            <li>Submit a Report: Provide details about the suspicious activity or crime you've observed. You can include text descriptions, images, videos, or audio recordings as evidence.</li>
            <li>Stay Anonymous: We use advanced technology to protect your identity. Your personal information is never shared with authorities.</li>
            <li>Help Your Community: Your report can assist law enforcement agencies in preventing crimes and maintaining community safety.</li>
          </ol>
        </div>
        <div className="about-buttons-container">
          <button className="secondary-button">Learn More</button>
        </div>
        <div className="supporters-container">
          <h2>Our Supporters</h2>
          <div className="supporter">
            <img src={Supporter1logo} alt="Supporter 1 Logo" />
            <p>National Intelligence Grid(NATGRID)</p>
          </div>
          <div className="supporter">
            <img src={Supporter2logo} alt="Supporter 2 Logo" />
            <p>Ministry of Home Affairs(MHA)</p>
          </div>
        </div>
        </div>
      </div>
    </div>
  );
};

export default About;