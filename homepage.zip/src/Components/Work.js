import React from "react";
import MissionpageImage from "../Assets/mission.png";

const Work = () => {
  return (
    <div className="work-section-wrapper">
      <div className="work-section-content">
        <div className="work-section-text">
          <p className="primary-subheading">Look At Our Successful Story</p>
          <h1 className="primary-heading">Chain Snatching Crime Solved</h1>
          <p className="primary-text">
            In the bustling streets of Mumbai, chain snatching incidents had been on the rise, leaving residents feeling vulnerable while going about their daily lives. The culprits operated with audacity, often targeting unsuspecting victims in broad daylight.
          </p>
          <p className="primary-text">
            One courageous individual, who wished to protect their identity, decided to take action. They utilized the Anonymous Crime Reporting System, providing critical information about a recent chain snatching incident they had witnessed. The report included:
          </p>
          <ul>
            <li>A detailed description of the assailant</li>
            <li>The precise location and time of the incident</li>
            <li>A brief account of the victim's description</li>
            <li>Additional information about the getaway vehicle used by the criminal</li>
          </ul>
        </div>
        <img src={MissionpageImage} alt="Chain Snatching" className="chain-snatching-image" />
      </div>
      <p className="mainpoint">
          <pre>                                                  Upon receiving the anonymous tip, local law enforcement agencies initiated a rapid response. The tip provided essential details that allowed the police </pre>
          <pre>                                                  to launch an investigation with a clear direction.</pre>
          <pre>                                                  Through diligent work and the information provided anonymously, law enforcement officers identified and apprehended the chain snatcher within days.</pre>
          <pre>                                                  The evidence gathered from the scene aligned perfectly with the information submitted by the anonymous tipster, ensuring a swift resolution.</pre>
          <pre>                                                  Thanks to the collective efforts of law enforcement and the anonymous tipster, chain snatching incidents in Mumbai have seen a significant decline.</pre>
          <pre>                                                  The community can now walk the streets with greater confidence and security.</pre>
        </p>
    </div>
  );
};

export default Work;

