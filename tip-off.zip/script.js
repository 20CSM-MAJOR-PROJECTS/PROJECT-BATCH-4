document.addEventListener("DOMContentLoaded", function () {
    const navigationItems = document.querySelectorAll("#navigation li");
    const nextButton = document.getElementById("nextButton");
    const form = document.getElementById("myForm");
    const description = document.getElementById("description");
    const policeStationSelect = document.getElementById("policeStation");
    const alertBox = document.getElementById("alert-box");

    let currentIndex = 0;

    nextButton.addEventListener("click", function () {
        if (!isFormEmpty()) {
            // Hide the alert message
            alertBox.style.display = "none";

            navigationItems[currentIndex].classList.remove("active");
            currentIndex = (currentIndex + 1) % navigationItems.length;
            navigationItems[currentIndex].classList.add("active");
        } else {
            showAlert("Please fill in all required fields before proceeding.");
        }
    });

    function isFormEmpty() {
        // Check if any of the required fields are empty
        if (description.value.trim() === "" || policeStationSelect.value === "") {
            return true;
        }
        return false;
    }

    function showAlert(message) {
        const alertMessage = document.getElementById("alert-message");
        alertMessage.textContent = message;
        alertBox.style.display = "block";
    }
});

// Get references to the district, city, and police station select elements
const districtSelect = document.getElementById("district");
const citySelect = document.getElementById("city");
const policeStationSelect = document.getElementById("policeStation");

// Define a mapping of districts, cities, and police stations
const data = {
    district1: {
        cities: ["Guntur", "Sattenapalli", "Tenali","Narasraopet"],
        policeStations: ["Arundalpet police station", "Old Guntur Police Station", "Tenali 1 Town Police Station","Tenali 2 Town Police Station"],
    },
    district2: {
        cities: ["Ongole", "Addanki", "Chimakurty"],
        policeStations: ["Ongole I Town Police Station","Ongole II Town Police Station","Kanigiri Police Station","Addanki Police Station"],
    },
    district3: {
        cities: [""],
        policeStations: ["Kurnool I town Police Station","Kurnool II town Police Station","Kurnool III town Police Station",],
    },
    district4: {
        cities: ["chirala"],
        policeStations: ["Station C1", "Station C2", "Station C3"],
    },
    district5: {
        cities: ["Vijayawada",],
        policeStations: ["Station C1", "Station C2", "Station C3"],
    },
    district6: {
        cities: [""],
        policeStations: ["Station C1", "Station C2", "Station C3"],
    },
    // Add more districts, cities, and police stations as needed
};

// Function to populate city options based on the selected district
function populateCities() {
    const selectedDistrict = districtSelect.value;
    const cities = data[selectedDistrict].cities;

    // Clear current options
    citySelect.innerHTML = "";

    // Add new options
    cities.forEach((city) => {
        const option = document.createElement("option");
        option.text = city;
        option.value = city;
        citySelect.appendChild(option);
    });

    // Trigger population of police station options based on the selected city
    populatePoliceStations();
}

// Function to populate police station options based on the selected city
function populatePoliceStations() {
    const selectedCity = citySelect.value;
    const policeStations = data[districtSelect.value].policeStations;

    // Clear current options
    policeStationSelect.innerHTML = "";

    // Add new options
    policeStations.forEach((station) => {
        const option = document.createElement("option");
        option.text = station;
        option.value = station;
        policeStationSelect.appendChild(option);
    });
}

// Event listeners to trigger population of options
districtSelect.addEventListener("change", populateCities);
citySelect.addEventListener("change", populatePoliceStations);

// Initially populate the cities and police stations based on the default district
populateCities();
function updateDateTime() {
    var datetimeElement = document.getElementById("datetime");
    var currentDate = new Date();
    
    var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' };
    var formattedDateTime = currentDate.toLocaleDateString('en-US', options);
    
    datetimeElement.textContent = formattedDateTime;
}

// Call the updateDateTime function initially and then at regular intervals (e.g., every second)
updateDateTime();
setInterval(updateDateTime, 1000); // Update every second

document.addEventListener("DOMContentLoaded", function () {
    var nextButton = document.getElementById("nextButton");
    var myForm = document.getElementById("myForm");

    nextButton.addEventListener("click", function (e) {
        var formFields = myForm.querySelectorAll("input, select, textarea");
        var emptyFields = [];

        formFields.forEach(function (field) {
            if (field.required) {
                if (field.type === "radio") {
                    var radioGroupName = field.getAttribute("name");
                    var radioGroup = document.querySelectorAll('input[name="' + radioGroupName + '"]');
                    var isChecked = Array.from(radioGroup).some(function (radio) {
                        return radio.checked;
                    });
                    if (!isChecked) {
                        emptyFields.push(radioGroupName);
                    }
                } else if (!field.value.trim()) {
                    field.style.border = "1px solid red"; // Add visual indication to required fields
                    emptyFields.push(field.id);
                } else {
                    field.style.border = ""; // Reset border for valid fields
                }
            }
        });

        if (emptyFields.length > 0) {
            e.preventDefault(); // Prevent navigation
            var errorMessage = "Please fill out the following fields:\n" + emptyFields.join(", ");
            displayAlert(errorMessage);
        }
    });
});

function displayAlert(message) {
    var alertBox = document.getElementById("alert-box");
    var alertMessage = document.getElementById("alert-message");

    alertMessage.textContent = message;
    alertBox.style.display = "block";
}

function closeAlert() {
    var alertBox = document.getElementById("alert-box");
    alertBox.style.display = "none";
}

